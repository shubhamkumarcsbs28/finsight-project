"""Placeholder for the fictional demo data generator.

The seed command will be implemented after authentication, account, transaction,
ledger, and fraud workflows are available.
"""

if __name__ == "__main__":
    raise SystemExit("Demo seeding is planned for a later implementation phase.")
