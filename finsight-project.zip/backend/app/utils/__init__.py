"""Shared backend utilities."""
