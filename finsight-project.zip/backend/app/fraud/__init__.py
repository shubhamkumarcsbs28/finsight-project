"""Transparent, rule-based fraud detection engine."""
