from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.core.config import settings
from app.database import create_tables
from app.models import Account, FraudAlert, LedgerEntry, Transaction, User  # noqa: F401
from app.routers.health import router as health_router


@asynccontextmanager
async def lifespan(_: FastAPI):
    # This is intentionally limited to local foundation setup. Versioned migrations
    # will replace create_all before a production-like deployment.
    create_tables()
    yield


app = FastAPI(
    title=settings.app_name,
    description=(
        "Educational FinTech transaction and fraud detection API. "
        "Not a production banking system."
    ),
    version="0.1.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(health_router, prefix="/api")
