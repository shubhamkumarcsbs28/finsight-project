"""FinSight backend application package."""
