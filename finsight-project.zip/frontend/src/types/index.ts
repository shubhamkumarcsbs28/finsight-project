export type Severity = "LOW" | "MEDIUM" | "HIGH";

export type TransactionType = "CREDIT" | "DEBIT";

export interface Transaction {
  id: number;
  accountId: number;
  transactionType: TransactionType;
  amount: number;
  merchant?: string;
  category?: string;
  riskScore: number;
}
