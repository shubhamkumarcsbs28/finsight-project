import { Activity, ArrowDownLeft, ArrowUpRight, ShieldCheck } from "lucide-react";

const navigation = ["Dashboard", "Transactions", "Accounts", "Fraud Alerts", "Analytics"];

function App() {
  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-mark">
            <ShieldCheck size={20} />
          </div>
          <div>
            <strong>FinSight</strong>
            <span>Risk intelligence</span>
          </div>
        </div>

        <nav aria-label="Primary navigation">
          {navigation.map((item, index) => (
            <a className={index === 0 ? "nav-item active" : "nav-item"} href={`#${item.toLowerCase().replace(" ", "-")}`} key={item}>
              <span className="nav-dot" />
              {item}
            </a>
          ))}
        </nav>

        <div className="sidebar-note">
          <span className="eyebrow">Demo environment</span>
          <p>Fictional data only. Not a production banking system.</p>
        </div>
      </aside>

      <main className="main-content">
        <header className="topbar">
          <div>
            <span className="eyebrow">Wednesday, September 23, 2026</span>
            <h1>Good morning, Alex</h1>
          </div>
          <div className="status-pill"><span /> API foundation online</div>
        </header>

        <section className="hero">
          <div>
            <span className="eyebrow">Portfolio overview</span>
            <h2>See the signal behind every transaction.</h2>
            <p>The dashboard foundation is ready for account, ledger, and fraud workflows.</p>
          </div>
          <Activity size={52} strokeWidth={1.2} />
        </section>

        <section className="metric-grid" aria-label="Portfolio summary">
          <Metric label="Total balance" value="$84,240.50" />
          <Metric label="Transactions" value="1,284" icon={<ArrowUpRight size={18} />} />
          <Metric label="Credits this month" value="$32,870.00" icon={<ArrowDownLeft size={18} />} />
          <Metric label="Open fraud alerts" value="04" accent />
        </section>

        <section className="content-grid">
          <div className="panel">
            <div className="panel-heading">
              <div>
                <span className="eyebrow">Next phase</span>
                <h3>Foundation checklist</h3>
              </div>
              <span className="completion">1 / 8</span>
            </div>
            <div className="checklist">
              <ChecklistItem label="React and FastAPI shells" done />
              <ChecklistItem label="Normalized PostgreSQL schema" done />
              <ChecklistItem label="Authentication and protected routes" />
              <ChecklistItem label="Atomic transactions and ledger" />
              <ChecklistItem label="Transparent fraud rules" />
            </div>
          </div>
          <div className="panel signal-panel">
            <span className="eyebrow">Risk posture</span>
            <div className="signal-score">—</div>
            <p>Risk scoring will activate when transaction ingestion is connected.</p>
            <div className="signal-line"><span /></div>
          </div>
        </section>
      </main>
    </div>
  );
}

function Metric({ label, value, icon, accent = false }: { label: string; value: string; icon?: React.ReactNode; accent?: boolean }) {
  return (
    <article className={accent ? "metric-card accent" : "metric-card"}>
      <span className="metric-label">{label}</span>
      <strong>{value}</strong>
      {icon && <span className="metric-icon">{icon}</span>}
    </article>
  );
}

function ChecklistItem({ label, done = false }: { label: string; done?: boolean }) {
  return (
    <div className="checklist-item">
      <span className={done ? "check done" : "check"}>{done ? "✓" : ""}</span>
      <span>{label}</span>
      <span className="item-status">{done ? "Ready" : "Planned"}</span>
    </div>
  );
}

export default App;
